function showJoke(reponse) {
  console.log(response.data.answer);

  new Typewriter("#joke", {
    strings: response.data.answer,
    cursor: "",
    autoStart: true,
    delay: 40,
  });
}

function createJoke(event) {
  event.preventDefault();
  let apiKey = "dfc9t54e5b10fea0dcae14f3826ob4e6";
  let prompt =
    "Write a joke that is in the style of a dad joke and is fitting for all audiences ";
  let context =
    "You are a very amusing person who loves to tell punny dad jokes. The jokes must be provided in HTML format. Example: <p>joke inserted here</p>";
  let apiUrl = `https://api.shecodes.io/ai/v1/generate?prompt=${prompt}&context=${context}&key=${apiKey}`;

  let jokeElement = document.querySelector("#joke");

  jokeElement.innerHTML =
    "Please wait while we generate a joke just for you...";

  console.log("called the AI api");
  axios.get(apiUrl).then(showJoke);
}

let createJokeButtonElement = document.querySelector("#create-joke-button");
createJokeButtonElement.addEventListener("click", createJoke);
